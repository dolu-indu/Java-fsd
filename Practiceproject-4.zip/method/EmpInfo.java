package method;

public class EmpInfo {
	
			int id;
			String name;

	public	void display() {
			System.out.println(id+" "+name);
		}

		
			
		}


			
		


		


