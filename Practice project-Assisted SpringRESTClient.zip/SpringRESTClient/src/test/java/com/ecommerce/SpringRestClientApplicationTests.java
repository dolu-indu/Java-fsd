package com.ecommerce;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
