package pack;

public class priaccessspecifier {
	  
	private void display() 
	    { 
	        System.out.println("You are using private access specifier"); 
	    } 


}
