package pack;

 class defAccessSpecifier {
	 void display() 
     { 
         System.out.println("You are using defalut access specifier"); 
     } 


}
