package com.ecommerce;

public @interface EnableZuulProxy {

}
