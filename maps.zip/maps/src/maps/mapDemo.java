package maps;
import java.util.*;
import java.util.Map.Entry;
	
	public class mapDemo {

		public static void main(String[] args) {
			
		
			HashMap<Integer,String> hm=new HashMap<Integer,String>();      
		      hm.put(1,"Tom");    
		      hm.put(2,"Mani");    
		      hm.put(3,"Cherry");   
		      System.out.println("\nThe elements of Hashmap are ");  
		      for(Entry<Integer, String> m:hm.entrySet()){    
		       System.out.println(m.getKey()+" "+m.getValue());    
		      }
		      
		    
		       
		      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
		      
		      ht.put(4,"Akshara");  
		      ht.put(5,"Rani");  
		      ht.put(6,"John");  
		      ht.put(7,"Josh");  

		      System.out.println("\nThe elements of HashTable are ");  
		      for(@SuppressWarnings("rawtypes") Map.Entry n:ht.entrySet()){    
		       System.out.println(n.getKey()+" "+n.getValue());    
		      }
		       
		      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
		      map.put(8,"Ananya");    
		      map.put(9,"Chinni");    
		      map.put(10,"Catie");       
		      
		      System.out.println("\nThe elements of TreeMap are ");  
		      for(@SuppressWarnings("rawtypes") Map.Entry l:map.entrySet()){    
		       System.out.println(l.getKey()+" "+l.getValue());    
		      }    
		      
		   }  
	}






